---
title: Link
data: 2018.4-2018.8
subtitle: What the hell's going on?
thumbnail: https://github.com/CMSoftware/CMSoftware.github.io/blob/master/images/7.png?raw=true
categories: 校园网连接
author: 
  nick: FDELO
  link: https://www.github.com/FDELO1998

---

Welcome to [Hexo](https://hexo.io/)! 
本校学生可以再该平台上租借校园网 
方便校园网闲置的同学赚取零花钱补贴网费和偶尔用一次的同学租借
可实现时间到期自动断网等保证租借的公平性
待上线 Check [documentation](https://hexo.io/docs/) for more info. If you get any problems when using Hexo, you can find the answer in [troubleshooting](https://hexo.io/docs/troubleshooting.html) or you can ask me on [GitHub](https://github.com/hexojs/hexo/issues).

## 校园网连接项目

### Create a new post

``` bash
$ hexo new "My New Post"
```

More info: [Writing](https://hexo.io/docs/writing.html)

### Run server

``` bash
$ hexo server
```

More info: [Server](https://hexo.io/docs/server.html)

### Generate static files

``` bash
$ hexo generate
```

More info: [Generating](https://hexo.io/docs/generating.html)

### Deploy to remote sites

``` bash
$ hexo deploy
```

More info: [Deployment](https://hexo.io/docs/deployment.html)
