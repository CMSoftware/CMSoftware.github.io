---
title: 关于我们
date: 2019-04-02 19:02:17
type: 关于创明
layout: about
background: img/15.png

---

<h3>创明工作室</h3>
<p style="text-align: center">创明工作室是隶属于创新创业学院下的软件开发工作室，工作室主要由计科院、数统院学生组成。工作室条件良好，设施齐全。同学们在其中可以自由学习html，css，JavaScript，python,java,node.js,c++...等各种计算机语言。学习氛围自由且严谨。主要分为网站组，软件组，设计组三个组别。</p>
<img src="img/创明.png">